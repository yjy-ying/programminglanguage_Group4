import javax.swing.*;
import java.awt.*;
import java.time.*;
import java.util.*;
import java.util.List;

import com.github.lgooddatepicker.components.DatePicker;
import com.github.lgooddatepicker.components.TimePicker;

public class DiningApp {
    private User user;
    private String userId;
    private JPanel panel;
    private JPanel eventListPanel;

    public DiningApp(String userId, User user) {
        this.userId = userId;
        this.user = user;
        panel = new JPanel(new BorderLayout());

        eventListPanel = new JPanel();
        eventListPanel.setLayout(new BoxLayout(eventListPanel, BoxLayout.Y_AXIS));
        JScrollPane scroll = new JScrollPane(eventListPanel);

        JPanel topButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton allEventsButton = new JButton("所有活動");
        JButton reservedEventsButton = new JButton("已預約活動");
        JButton pastEventsButton = new JButton("已結束活動");

        allEventsButton.addActionListener(e -> showAllEvents());
        reservedEventsButton.addActionListener(e -> showReservedEvents(this.user));
        pastEventsButton.addActionListener(e -> showPastEvents(this.user));

        topButtonPanel.add(allEventsButton);
        topButtonPanel.add(reservedEventsButton);
        topButtonPanel.add(pastEventsButton);

        panel.add(topButtonPanel, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);

        reloadEvents();
    }

    public JPanel getPanel() {
        return panel;
    }

    public void createEvent() {
        String location = JOptionPane.showInputDialog(panel, "請輸入活動地點：");
        if (location == null || location.trim().isEmpty())
            return;

        LocalDateTime dateTime = showDateTimePicker(panel);
        if (dateTime == null)
            return;

        int limit = -1;
        while (true) {
            String limitStr = JOptionPane.showInputDialog(panel, "請輸入人數上限（最少 2 人）：");
            if (limitStr == null)
                return;

            try {
                limit = Integer.parseInt(limitStr.trim());
                if (limit <= 1)
                    throw new NumberFormatException();
                break;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(panel, "人數不符，請重新輸入（最少 2 人）");
            }
        }

        try {
            int eventId = DatabaseHelper.createEvent(location, userId, dateTime, limit);
            DatabaseHelper.joinEvent(eventId, userId);
            reloadEvents();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void reloadEvents() {
        eventListPanel.removeAll();

        try {
            ArrayList<DiningEvent> events = DatabaseHelper.loadEvents();
            LocalDateTime now = LocalDateTime.now();

            for (DiningEvent event : events) {
                if (event.getEventTime().isBefore(now) && !event.isJoined(userId)) {
                    continue;
                }

                if (event.getParticipantCount() >= event.getLimit()
                    && !event.isJoined(userId)
                    && !event.getCreatorId().equals(userId)) {
                    continue;
                }

                eventListPanel.add(new EventPanel(event, userId, this));
            }

            eventListPanel.revalidate();
            eventListPanel.repaint();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showAllEvents() {
        reloadEvents();
    }

    public void showReservedEvents(User currentUser) {
        eventListPanel.removeAll();

        try {
            ArrayList<DiningEvent> events = DatabaseHelper.loadEvents();
            LocalDateTime now = LocalDateTime.now();

            for (DiningEvent event : events) {
                if (event.getEventTime().isBefore(now)) continue;
                if (event.isJoined(currentUser.getStudentId())) {
                    eventListPanel.add(new EventPanel(event, userId, this));
                }
            }

            eventListPanel.revalidate();
            eventListPanel.repaint();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showPastEvents(User currentUser) {
        eventListPanel.removeAll();

        try {
            ArrayList<DiningEvent> events = DatabaseHelper.loadEvents();
            LocalDateTime now = LocalDateTime.now();

            for (DiningEvent event : events) {
                if (!event.getEventTime().isBefore(now)) continue;
                if (event.isJoined(currentUser.getStudentId())) {
                    eventListPanel.add(new EventPanel(event, userId, this));
                }
            }

            eventListPanel.revalidate();
            eventListPanel.repaint();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void refreshUI() {
        reloadEvents();
    }

    public LocalDateTime showDateTimePicker(Component parent) {
        DatePicker datePicker = new DatePicker();
        TimePicker timePicker = new TimePicker();

        JPanel panel = new JPanel(new GridLayout(2, 2, 10, 10));
        panel.add(new JLabel("選擇日期："));
        panel.add(datePicker);
        panel.add(new JLabel("選擇時間："));
        panel.add(timePicker);

        int result = JOptionPane.showConfirmDialog(parent, panel, "選擇活動時間", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            LocalDate date = datePicker.getDate();
            LocalTime time = timePicker.getTime();
            if (date != null && time != null) {
                return LocalDateTime.of(date, time);
            }
        }
        return null;
    }
}
