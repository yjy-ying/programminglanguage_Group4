import java.sql.*;

public class DBHelper {
    private static final String DB_URL = "jdbc:mysql://140.119.19.73:3315/MG10?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "MG10";
    private static final String DB_PASS = "JVkMkM";

    static {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             Statement stmt = conn.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS users (" +
                         "id INT AUTO_INCREMENT PRIMARY KEY," +
                         "name VARCHAR(100) NOT NULL," +
                         "student_id VARCHAR(20) UNIQUE NOT NULL," +
                         "password VARCHAR(100) NOT NULL," +
                         "verification_code VARCHAR(10)," +
                         "is_verified BOOLEAN DEFAULT 0)";
            stmt.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
    }

    public static boolean login(String studentId, String password) {
        try (Connection conn = getConnection()) {
            String sql = "SELECT * FROM users WHERE student_id=? AND password=? AND is_verified=1";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, studentId);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean register(String name, String studentId, String password, String code) {
        try (Connection conn = getConnection()) {
            String sql = "INSERT INTO users (name, student_id, password, verification_code, is_verified) VALUES (?, ?, ?, ?, 1)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, studentId);
            stmt.setString(3, password);
            stmt.setString(4, code);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
