import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class MailboxFrame extends JFrame {
    private static final String DB_URL = "jdbc:mysql://140.119.19.73:3315/MG10?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "MG10";
    private static final String DB_PASS = "JVkMkM";

    private JTextArea messageArea; 

    public MailboxFrame(String userId) {
        setTitle("📬 我的提醒信箱");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        messageArea = new JTextArea(); 
        messageArea.setFont(new Font("Microsoft JhengHei", Font.PLAIN, 14));
        messageArea.setEditable(false);
        messageArea.setLineWrap(true);       
        messageArea.setWrapStyleWord(true);     

        JScrollPane scrollPane = new JScrollPane(messageArea);
        add(scrollPane, BorderLayout.CENTER);

        loadMessages(userId);
    }

    private void loadMessages(String userId) {
        ArrayList<String> messages = new ArrayList<>();
        String sql = "SELECT content, sent_time FROM mailbox WHERE user_id = ? ORDER BY sent_time DESC";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String content = rs.getString("content");

                messages.add("【提醒】\n" + content + "\n------------------------------------------------------------------------------\n");
            }

            if (messages.isEmpty()) {
                messageArea.setText("📭 沒有訊息，快去報名吃飯活動吧！");
            } else {
                messageArea.setText(String.join("", messages));
            }

        } catch (SQLException e) {
            messageArea.setText("❗ 無法載入訊息：" + e.getMessage());
        }
    }
}
