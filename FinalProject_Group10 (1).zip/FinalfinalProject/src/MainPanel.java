import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class MainPanel {
    private JPanel panel;
    private JPanel contentPanel;
    private DiningApp diningApp;
    private String userId;
    private User currentUser;
    private JPanel sideMenu;
    private JFrame frame;

    public MainPanel(JFrame frame, String userId) {
        applyGlobalTheme();

        this.frame = frame;
        this.userId = userId;
        this.panel = new JPanel(new BorderLayout());
        this.contentPanel = new JPanel(new BorderLayout());

        try {
            this.currentUser = UserDAO.getProfileByStudentId(userId);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "載入使用者資料失敗：" + e.getMessage());
        }

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton menuButton = new JButton("\u2630");
        menuButton.setFont(new Font("SansSerif", Font.BOLD, 18));
        menuButton.setFocusPainted(false);
        menuButton.setContentAreaFilled(false);
        menuButton.setBorderPainted(false);

        JLabel userLabel = new JLabel(" " + userId);
        userLabel.setFont(new Font("Arial", Font.BOLD, 16));

        JPanel leftTopPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        leftTopPanel.setOpaque(false);
        leftTopPanel.add(menuButton);
        leftTopPanel.add(userLabel);

        JButton refreshButton = new JButton("\ud83d\udd04");
        refreshButton.setFont(new Font("SansSerif", Font.PLAIN, 12));
        refreshButton.addActionListener(e -> diningApp.refreshUI());

        topPanel.add(leftTopPanel, BorderLayout.WEST);
        topPanel.add(refreshButton, BorderLayout.EAST);

        sideMenu = new JPanel();
        sideMenu.setLayout(new BoxLayout(sideMenu, BoxLayout.Y_AXIS));
        sideMenu.setPreferredSize(new Dimension(120, 0));
        sideMenu.setVisible(false);

        JButton profileBtn = new JButton("個人檔案");
        profileBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        profileBtn.addActionListener(e -> new UserProfile(currentUser, userId));

        JButton inboxBtn = new JButton("我的信箱");
        inboxBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        inboxBtn.addActionListener(e -> new MailboxFrame(userId).setVisible(true));

        JButton logoutBtn = new JButton("登出");
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutBtn.setForeground(Color.RED);
        logoutBtn.addActionListener(e -> {
            frame.dispose();

            JFrame loginFrame = new JFrame("Login");
            LoginFrame loginPanel = new LoginFrame(newUserId -> {
                try {
                    JFrame newFrame = new JFrame("Dining System");
                    MainPanel mainPanel = new MainPanel(newFrame, newUserId);
                    newFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    newFrame.setSize(900, 600);
                    newFrame.setLocationRelativeTo(null);
                    newFrame.setContentPane(mainPanel.getPanel());
                    newFrame.setVisible(true);
                    loginFrame.dispose();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            });

            loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            loginFrame.setSize(400, 400);
            loginFrame.setLocationRelativeTo(null);
            loginFrame.setContentPane(loginPanel.getPanel());
            loginFrame.setVisible(true);
        });

        sideMenu.add(Box.createVerticalStrut(20));
        sideMenu.add(profileBtn);
        sideMenu.add(Box.createVerticalStrut(10));
        sideMenu.add(inboxBtn);
        sideMenu.add(Box.createVerticalStrut(10));
        sideMenu.add(logoutBtn);

        menuButton.addActionListener(e -> sideMenu.setVisible(!sideMenu.isVisible()));

        loadUserData();

        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(sideMenu, BorderLayout.WEST);
        panel.add(contentPanel, BorderLayout.CENTER);
    }

    private void loadUserData() {
        contentPanel.removeAll();

        diningApp = new DiningApp(userId, currentUser);
        contentPanel.add(diningApp.getPanel(), BorderLayout.CENTER);

        JButton createButton = new JButton("\u2795 創建活動");
        createButton.addActionListener(e -> diningApp.createEvent());
        JPanel createPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        createPanel.add(createButton);
        contentPanel.add(createPanel, BorderLayout.SOUTH);

        contentPanel.revalidate();
        contentPanel.repaint();

        ReminderManager.runAllReminders();
    }

    public JPanel getPanel() {
        return panel;
    }

    private void applyGlobalTheme() {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
            UIManager.put("control", new Color(245, 245, 255));
            UIManager.put("nimbusBase", new Color(80, 60, 150));
            UIManager.put("nimbusBlueGrey", new Color(200, 200, 230));
            UIManager.put("nimbusFocus", new Color(180, 180, 255));
        } catch (Exception ignored) {}
    }
}

