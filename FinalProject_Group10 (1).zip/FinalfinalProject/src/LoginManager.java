// Class 12: LoginManager.java - 移除測試資料，改為從資料庫驗證
public class LoginManager {
    public boolean login(String username, String password) {
        return DBHelper.login(username, password);
    }
}