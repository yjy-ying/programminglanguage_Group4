
public class User {
    private int id; 
    private String studentId;
    private String username; 
    private String name;
    private String gender;
    private String interests;
    private String avoidFood;
    private String profileImagePath;
    private int attendedCount;
    private int bookedCount;
    private int ratingTotal;
    private int ratingCount;

    public User() {}

    public User(int id, String studentId, String username, String name, String gender,
                String interests, String avoidFood, String profileImagePath,
                int attendedCount, int bookedCount, int ratingTotal, int ratingCount) {
        this.id = id;
        this.studentId = studentId;
        this.username = username;
        this.name = name;
        this.gender = gender;
        this.interests = interests;
        this.avoidFood = avoidFood;
        this.profileImagePath = profileImagePath;
        this.attendedCount = attendedCount;
        this.bookedCount = bookedCount;
        this.ratingTotal = ratingTotal;
        this.ratingCount = ratingCount;
    }

    public int getId() {
        return id;
    }

    public String getStudentId() {
        return studentId;
    }

    public String getUsername() {
        return username;
    }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public String getInterests() {
        return interests;
    }

    public String getAvoidFood() {
        return avoidFood;
    }

    public String getProfileImagePath() {
        return profileImagePath;
    }

    public int getAttendedCount() {
        return attendedCount;
    }

    public int getBookedCount() {
        return bookedCount;
    }

    public int getRatingTotal() {
        return ratingTotal;
    }

    public int getRatingCount() {
        return ratingCount;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setInterests(String interests) {
        this.interests = interests;
    }

    public void setAvoidFood(String avoidFood) {
        this.avoidFood = avoidFood;
    }

    public void setProfileImagePath(String profileImagePath) {
        this.profileImagePath = profileImagePath;
    }

    public void setAttendedCount(int attendedCount) {
        this.attendedCount = attendedCount;
    }

    public void setBookedCount(int bookedCount) {
        this.bookedCount = bookedCount;
    }

    public void setRatingTotal(int ratingTotal) {
        this.ratingTotal = ratingTotal;
    }

    public void setRatingCount(int ratingCount) {
        this.ratingCount = ratingCount;
    }

    public double getAverageRating() {
        return ratingCount > 0 ? (double) ratingTotal / ratingCount : 0.0;
    }

    public double getAttendanceRate() {
        return bookedCount > 0 ? (attendedCount * 100.0) / bookedCount : 0.0;
    }
}
