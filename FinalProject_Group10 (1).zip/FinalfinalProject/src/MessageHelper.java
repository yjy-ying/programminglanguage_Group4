import java.sql.*;

public class MessageHelper {
    private static final String DB_URL = "jdbc:mysql://140.119.19.73:3315/MG10?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "MG10";
    private static final String DB_PASS = "JVkMkM";

    public static void sendMessage(String userId, String content) {
        String sql = "INSERT INTO mailbox (user_id, content, sent_time) VALUES (?, ?, NOW())";
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, userId);
            stmt.setString(2, content);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.err.println("❗ 發送訊息失敗: " + e.getMessage());
            e.printStackTrace();
        }
    }
    



}
