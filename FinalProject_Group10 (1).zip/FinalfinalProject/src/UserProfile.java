import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.sql.*;

public class UserProfile extends JFrame {
    private final User currentUser;
    private final String viewerId;
    private final boolean isSelf;
    private boolean isEditing = false;

    private JLabel avatarLabel;
    private JLabel interestLabel, avoidLabel, genderLabel;
    private JTextArea interestArea, avoidFoodArea;
    private JScrollPane scrollInterest, scrollAvoid;
    private JTextField nicknameField;
    private JComboBox<String> genderComboBox;
    private JButton editButton, changeAvatarButton, removeAvatarButton, saveNickButton, deleteNickButton;

    private JPanel gridPanel;
    private GridBagConstraints gbc;

    public UserProfile(User targetUser, String viewerId) {
        this.currentUser = targetUser;
        this.viewerId = viewerId;
        this.isSelf = viewerId.equals(targetUser.getStudentId());

        setTitle("個人檔案");
        setSize(360, 580);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        initUI();
        setVisible(true);
    }

    private void initUI() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        mainPanel.setBackground(Color.WHITE);

        String imgPath = currentUser.getProfileImagePath();
        File imgFile = (imgPath != null) ? new File(imgPath) : null;
        if (imgFile == null || !imgFile.exists()) {
            imgPath = "avatars/images.png";
        }
        ImageIcon icon = new ImageIcon(imgPath);
        Image scaled = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        avatarLabel = new JLabel(new ImageIcon(scaled));
        avatarLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(avatarLabel);
        mainPanel.add(Box.createVerticalStrut(10));

        if (isSelf) {
            JPanel avatarBtnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
            changeAvatarButton = new JButton("變更頭像");
            removeAvatarButton = new JButton("移除頭像");
            changeAvatarButton.addActionListener(this::handleChangeAvatar);
            removeAvatarButton.addActionListener(this::handleRemoveAvatar);
            avatarBtnPanel.add(changeAvatarButton);
            avatarBtnPanel.add(removeAvatarButton);
            mainPanel.add(avatarBtnPanel);
        }

        JLabel nameLabel = new JLabel(currentUser.getUsername());
        mainPanel.add(Box.createVerticalStrut(15));

        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(nameLabel);
        mainPanel.add(Box.createVerticalStrut(10));

        gridPanel = new JPanel(new GridBagLayout());
        gridPanel.setOpaque(false);
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        addRow(gridPanel, 0, "學號：", currentUser.getStudentId());

        // 性別
        gbc.gridy = 1;
        gbc.gridx = 0;
        gridPanel.add(new JLabel("性別："), gbc);
        gbc.gridx = 1;
        genderLabel = new JLabel(currentUser.getGender() == null ? "未填寫" : currentUser.getGender());
        genderComboBox = new JComboBox<>(new String[]{"男", "女", "其他"});
        genderComboBox.setSelectedItem(currentUser.getGender());
        genderComboBox.setVisible(false);
        gridPanel.add(genderLabel, gbc);
        gridPanel.add(genderComboBox, gbc);

        // 標籤
        gbc.gridy++;
        gbc.gridx = 0;
        gridPanel.add(new JLabel("標籤："), gbc);
        gbc.gridx = 1;
        interestLabel = new JLabel(currentUser.getInterests());
        interestArea = new JTextArea(currentUser.getInterests(), 2, 20);
        interestArea.setLineWrap(true);
        interestArea.setWrapStyleWord(true);
        interestArea.setFont(new Font("SansSerif", Font.PLAIN, 12));
        scrollInterest = new JScrollPane(interestArea);
        scrollInterest.setPreferredSize(new Dimension(200, 40));
        scrollInterest.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        scrollInterest.setVisible(false);
        gridPanel.add(interestLabel, gbc);
        gridPanel.add(scrollInterest, gbc);

        // 忌口
        gbc.gridy++;
        gbc.gridx = 0;
        gridPanel.add(new JLabel("忌口："), gbc);
        gbc.gridx = 1;
        avoidLabel = new JLabel(currentUser.getAvoidFood());
        avoidFoodArea = new JTextArea(currentUser.getAvoidFood(), 2, 20);
        avoidFoodArea.setLineWrap(true);
        avoidFoodArea.setWrapStyleWord(true);
        avoidFoodArea.setFont(new Font("SansSerif", Font.PLAIN, 12));
        scrollAvoid = new JScrollPane(avoidFoodArea);
        scrollAvoid.setPreferredSize(new Dimension(200, 40));
        scrollAvoid.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        scrollAvoid.setVisible(false);
        gridPanel.add(avoidLabel, gbc);
        gridPanel.add(scrollAvoid, gbc);

        if (!isSelf) {
            gbc.gridy++;
            gbc.gridx = 0;
            gridPanel.add(new JLabel("自訂暱稱："), gbc);
            gbc.gridx = 1;
            nicknameField = new JTextField();
            nicknameField.setPreferredSize(new Dimension(120, 28));
            String existing = DatabaseHelper.getNickname(viewerId, currentUser.getStudentId());
			if (existing != null) nicknameField.setText(existing);
            gridPanel.add(nicknameField, gbc);
        }

        mainPanel.add(gridPanel);
        mainPanel.add(Box.createVerticalStrut(15));

        if (!isSelf) {
            JPanel nickButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
            saveNickButton = new JButton("儲存");
            deleteNickButton = new JButton("刪除");
            saveNickButton.addActionListener(this::saveNickname);
            deleteNickButton.addActionListener(this::deleteNickname);
            nickButtonPanel.add(saveNickButton);
            nickButtonPanel.add(deleteNickButton);
            mainPanel.add(nickButtonPanel);
        }

        if (isSelf) {
            editButton = new JButton("✎ 編輯資料");
            editButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            editButton.addActionListener(this::toggleEditMode);
            mainPanel.add(editButton);
        }

        setContentPane(mainPanel);
    }

    private void toggleEditMode(ActionEvent e) {
        isEditing = !isEditing;
        interestLabel.setVisible(!isEditing);
        scrollInterest.setVisible(isEditing);
        avoidLabel.setVisible(!isEditing);
        scrollAvoid.setVisible(isEditing);
        genderLabel.setVisible(!isEditing);
        genderComboBox.setVisible(isEditing);
        editButton.setText(isEditing ? "💾 儲存資料" : "✎ 編輯資料");
        if (!isEditing) handleSave();
    }

    private void handleSave() {
        try {
            String interests = interestArea.getText();
            String avoids = avoidFoodArea.getText();
            String gender = (String) genderComboBox.getSelectedItem();
            currentUser.setInterests(interests);
            currentUser.setAvoidFood(avoids);
            currentUser.setGender(gender);
            interestLabel.setText(interests);
            avoidLabel.setText(avoids);
            genderLabel.setText(gender);
            UserDAO.update(currentUser);
            JOptionPane.showMessageDialog(this, "資料已更新！");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "更新失敗: " + ex.getMessage());
        }
    }

    private void handleChangeAvatar(ActionEvent e) {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileNameExtensionFilter("圖片檔案", "png", "jpg", "jpeg"));
        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selected = chooser.getSelectedFile();
            String ext = selected.getName().substring(selected.getName().lastIndexOf('.') + 1);
            String newPath = "avatars/" + currentUser.getStudentId() + "." + ext;
            try {
                Files.createDirectories(Paths.get("avatars"));
                Files.copy(selected.toPath(), Paths.get(newPath), StandardCopyOption.REPLACE_EXISTING);
                currentUser.setProfileImagePath(newPath);
                UserDAO.update(currentUser);
                JOptionPane.showMessageDialog(this, "頭像已更新！");
                this.dispose();
                new UserProfile(currentUser, viewerId);
            } catch (IOException | SQLException ex) {
                JOptionPane.showMessageDialog(this, "更新頭像失敗: " + ex.getMessage());
            }
        }
    }

    private void handleRemoveAvatar(ActionEvent e) {
        try {
            currentUser.setProfileImagePath("");
            UserDAO.update(currentUser);
            JOptionPane.showMessageDialog(this, "已移除頭像！");
            this.dispose();
            new UserProfile(currentUser, viewerId);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "移除頭像失敗: " + ex.getMessage());
        }
    }

    private void saveNickname(ActionEvent e) {
        String nick = nicknameField.getText().trim();
        try {
            if (!nick.isEmpty()) {
                DatabaseHelper.setNickname(viewerId, currentUser.getStudentId(), nick);
            } else {
                DatabaseHelper.deleteNickname(viewerId, currentUser.getStudentId());
            }
            JOptionPane.showMessageDialog(this, "暱稱已更新！");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "暱稱更新失敗: " + ex.getMessage());
        }
    }

    private void deleteNickname(ActionEvent e) {
        try {
            DatabaseHelper.deleteNickname(viewerId, currentUser.getStudentId());
            nicknameField.setText("");
            JOptionPane.showMessageDialog(this, "暱稱已刪除！");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "刪除暱稱失敗: " + ex.getMessage());
        }
    }

    private void addRow(JPanel panel, int row, String label, String value) {
        gbc.gridy = row;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(new JLabel(label), gbc);

        gbc.gridx = 1;
        panel.add(new JLabel(value), gbc);
    }
}
