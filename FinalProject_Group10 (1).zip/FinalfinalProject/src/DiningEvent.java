
import java.time.LocalDateTime;
import java.util.Set;

public class DiningEvent {
    private int id;
    private String location;
    private String creatorId;
    private Set<String> participants;
    private LocalDateTime eventTime;
    private int limit;

    public DiningEvent(int id, String location, String creatorId, Set<String> participants, LocalDateTime eventTime, int limit) {
        this.id = id;
        this.location = location;
        this.creatorId = creatorId;
        this.participants = participants;
        this.eventTime = eventTime;
        this.limit = limit;
    }

    public String getLocation() {
        return location;
    }

    public LocalDateTime getEventTime() {
        return eventTime;
    }

    public int getLimit() {
        return limit;
    }

    public int getParticipantCount() {
        return participants.size();
    }

    public boolean isJoined(String userId) {
        return participants.contains(userId);
    }

    public void join(String userId) {
        participants.add(userId);
    }

    public void cancel(String userId) {
        if (!userId.equals(creatorId))
            participants.remove(userId);
    }

    public String getParticipantList() {
        return participants.toString();
    }

    public int getId() {
        return id;
    }

    public String getCreatorId() {
        return creatorId;
    }
}
