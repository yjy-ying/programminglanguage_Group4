import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.SQLException;

public class EventPanel extends JPanel {
    private final DiningEvent event;
    private final String userId;
    private final DiningApp app;
    private final JLabel countLabel;

    public EventPanel(DiningEvent event, String userId, DiningApp app) {
        this.event = event;
        this.userId = userId;
        this.app = app;

        setLayout(new BorderLayout());
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                new EmptyBorder(15, 20, 15, 20)));
        setBackground(new Color(245, 245, 245));
        setMaximumSize(new Dimension(Integer.MAX_VALUE, 110));
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setOpaque(false);

        JLabel locationLabel = new JLabel("地點：" + event.getLocation());
        locationLabel.setFont(new Font("SansSerif", Font.BOLD, 14));

        JLabel timeLabel = new JLabel("時間：" + event.getEventTime().toString().replace("T", " ").substring(0, 16));
        timeLabel.setFont(new Font("SansSerif", Font.PLAIN, 13));

        countLabel = new JLabel("人數：" + event.getParticipantCount() + " / " + event.getLimit());
        countLabel.setFont(new Font("SansSerif", Font.PLAIN, 13));

        infoPanel.add(locationLabel);
        infoPanel.add(Box.createVerticalStrut(5));
        infoPanel.add(timeLabel);
        infoPanel.add(Box.createVerticalStrut(5));
        infoPanel.add(countLabel);

        JPanel rowPanel = new JPanel(new BorderLayout());
        rowPanel.setOpaque(false);
        rowPanel.add(infoPanel, BorderLayout.CENTER);

        if (event.getCreatorId().equals(userId)) {
            JPanel adminPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            adminPanel.setOpaque(false);

            JButton deleteButton = new JButton("刪除活動");
            deleteButton.setFont(new Font("SansSerif", Font.PLAIN, 12));
            deleteButton.setBackground(new Color(180, 60, 60));
            deleteButton.setForeground(Color.WHITE);
            deleteButton.setFocusPainted(false);
            deleteButton.addActionListener(e -> deleteEvent());

            JButton chatButton = new JButton("聊天室");
            chatButton.setFont(new Font("SansSerif", Font.PLAIN, 12));
            chatButton.addActionListener(e -> openChatroom());

            adminPanel.add(deleteButton);
            adminPanel.add(chatButton);

            rowPanel.add(adminPanel, BorderLayout.EAST);

        } else {
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            buttonPanel.setOpaque(false);

            JButton actionButton = new JButton(event.isJoined(userId) ? "取消報名" : "報名");
            actionButton.setBackground(event.isJoined(userId) ? new Color(200, 80, 80) : new Color(60, 140, 200));
            actionButton.setForeground(Color.WHITE);
            actionButton.setFocusPainted(false);
            actionButton.setFont(new Font("SansSerif", Font.BOLD, 13));
            actionButton.addActionListener(e -> handleAction());

            JButton chatButton = new JButton("聊天室");
            chatButton.setFont(new Font("SansSerif", Font.PLAIN, 12));
            chatButton.setEnabled(event.isJoined(userId));
            chatButton.addActionListener(e -> openChatroom());

            buttonPanel.add(actionButton);
            buttonPanel.add(chatButton);

            rowPanel.add(buttonPanel, BorderLayout.EAST);
        }

        add(rowPanel, BorderLayout.CENTER);
    }

    private void handleAction() {
        try {
            if (event.isJoined(userId)) {
                event.cancel(userId);
                DatabaseHelper.cancelEvent(event.getId(), userId);
                JOptionPane.showMessageDialog(this, "您已取消報名。");
            } else {
                if (event.getParticipantCount() >= event.getLimit()) {
                    JOptionPane.showMessageDialog(this, "活動人數已滿，無法報名。", "提示", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                event.join(userId);
                DatabaseHelper.joinEvent(event.getId(), userId);
                JOptionPane.showMessageDialog(this, "報名成功！");
            }
            app.refreshUI();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteEvent() {
        int confirm = JOptionPane.showConfirmDialog(this, "確定要刪除這個活動嗎？", "刪除確認", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                DatabaseHelper.deleteEvent(event.getId());
                JOptionPane.showMessageDialog(this, "活動已刪除");
                app.refreshUI();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "刪除失敗：" + e.getMessage(), "錯誤", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void openChatroom() {
        if (event.isJoined(userId) || event.getCreatorId().equals(userId)) {
            try {
                User user = UserDAO.getProfileByStudentId(userId);
                if (user != null) {
                    new ChatClient("127.0.0.1", 12345, event.getId(), userId, user.getUsername());

                } else {
                    JOptionPane.showMessageDialog(this, "無法取得使用者名稱。");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "查詢使用者名稱失敗：" + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "請先報名才能進入聊天室。", "禁止", JOptionPane.WARNING_MESSAGE);
        }
    }
}

