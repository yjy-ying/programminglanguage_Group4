import java.sql.*;

public class UserDAO {
    private static final String URL = "jdbc:mysql://140.119.19.73:3315/MG10?useSSL=false&serverTimezone=UTC";
    private static final String USER = "MG10";
    private static final String PASSWORD = "JVkMkM";

    public static boolean login(String studentId, String password) throws SQLException {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String sql = "SELECT * FROM users WHERE student_id=? AND password=?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, studentId);
                stmt.setString(2, password);
                ResultSet rs = stmt.executeQuery();
                return rs.next();
            }
        }
    }

    public static User getProfileByStudentId(String studentId) throws SQLException {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);

        // 嘗試 JOIN 查詢 users + profile
        String query = "SELECT p.*, u.name AS username " +
                       "FROM profile p " +
                       "JOIN users u ON p.student_id = u.student_id " +
                       "WHERE p.student_id = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, studentId);
        ResultSet rs = stmt.executeQuery();

        User user = null;
        if (rs.next()) {
            user = new User(
                rs.getInt("id"),
                studentId,
                rs.getString("username"),  // 來自 users.name
                rs.getString("name"),
                rs.getString("gender"),
                rs.getString("interests"),
                rs.getString("avoid_food"),
                rs.getString("profile_image_path"),
                rs.getInt("attended_count"),
                rs.getInt("booked_count"),
                rs.getInt("rating_total"),
                rs.getInt("rating_count")
            );
        }
        rs.close();
        stmt.close();

        // 若沒找到 profile，建立一筆空的 profile 資料
        if (user == null) {
            String insertSql = "INSERT INTO profile (student_id, name, gender, interests, avoid_food, attended_count, booked_count, rating_count, rating_total, profile_image_path) " +
                               "VALUES (?, '', NULL, '', '', 0, 0, 0, 0, NULL)";
            PreparedStatement insertStmt = conn.prepareStatement(insertSql);
            insertStmt.setString(1, studentId);
            insertStmt.executeUpdate();
            insertStmt.close();

            conn.close();
            return getProfileByStudentId(studentId); // 再查一次
        }

        conn.close();
        return user;
    }

    public static void update(User user) throws SQLException {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String sql = "UPDATE profile SET name=?, gender=?, interests=?, avoid_food=?, profile_image_path=?, attended_count=?, booked_count=?, rating_total=?, rating_count=? WHERE id=?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, user.getName());
                stmt.setString(2, user.getGender());
                stmt.setString(3, user.getInterests());
                stmt.setString(4, user.getAvoidFood());
                stmt.setString(5, user.getProfileImagePath());
                stmt.setInt(6, user.getAttendedCount());
                stmt.setInt(7, user.getBookedCount());
                stmt.setInt(8, user.getRatingTotal());
                stmt.setInt(9, user.getRatingCount());
                stmt.setInt(10, user.getId());
                stmt.executeUpdate();
            }
        }
    }
    public static User getById(int id) throws SQLException {
        Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);

        String query = "SELECT u.id, u.student_id, u.name AS username, " +
                       "p.name, p.gender, p.interests, p.avoid_food, p.profile_image_path, " +
                       "p.attended_count, p.booked_count, p.rating_total, p.rating_count " +
                       "FROM users u JOIN profile p ON u.student_id = p.student_id WHERE u.id = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();

        User user = null;
        if (rs.next()) {
            user = new User(
                rs.getInt("id"),
                rs.getString("student_id"),
                rs.getString("username"),
                rs.getString("name"),
                rs.getString("gender"),
                rs.getString("interests"),
                rs.getString("avoid_food"),
                rs.getString("profile_image_path"),
                rs.getInt("attended_count"),
                rs.getInt("booked_count"),
                rs.getInt("rating_total"),
                rs.getInt("rating_count")
            );
        }

        rs.close();
        stmt.close();
        conn.close();
        return user;
    }

}
