import java.awt.CardLayout;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class DiningSystemApp {
    private JFrame frame;
    private CardLayout cardLayout;
    private JPanel cardPanel;

    private LoginFrame loginFrame;
    private MainPanel mainPanel;

    private static final Dimension LOGIN_SIZE = new Dimension(400, 400);
    private static final Dimension MAIN_SIZE = new Dimension(900, 600);

    public DiningSystemApp() {
        frame = new JFrame("吃飯了啦!🍚");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        loginFrame = new LoginFrame(this::onLoginSuccess);
        cardPanel.add(loginFrame.getPanel(), "login");

        frame.add(cardPanel);
        frame.setSize(LOGIN_SIZE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        showLogin();
    }

    private void showLogin() {
        cardLayout.show(cardPanel, "login");
        frame.setSize(LOGIN_SIZE);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
    }

    private void onLoginSuccess(String studentId) {
        
        System.out.println("✅ 登入成功：" + studentId);

        mainPanel = new MainPanel(frame, studentId);
        cardPanel.add(mainPanel.getPanel(), "main");

        cardLayout.show(cardPanel, "main");
        frame.setSize(MAIN_SIZE);
        frame.setResizable(true);
        frame.setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(DiningSystemApp::new);
        ReminderManager.startReminderService();
    }
}

