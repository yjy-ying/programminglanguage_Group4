import javax.swing.*;
import java.awt.*;
import java.util.function.Consumer;

public class LoginFrame {
    private JPanel panel;
    private JTextField studentIdField;
    private JPasswordField passwordField;
    private JButton loginButton, registerButton;

    public LoginFrame(Consumer<String> onLoginSuccess) {
    	
        panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50)); 
        panel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // 標題
        JLabel titleLabel = new JLabel("LOGIN");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 28));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(titleLabel);

        // 副標題 
        JLabel subtitle = new JLabel("尋找你的飯飯之交!");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 14));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        subtitle.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));
        panel.add(subtitle);

        // 輸入欄位區
        Dimension fieldSize = new Dimension(300, 32);
        studentIdField = new JTextField();
        passwordField = new JPasswordField();
        studentIdField.setMaximumSize(fieldSize);
        passwordField.setMaximumSize(fieldSize);

        panel.add(makeField("Student ID", studentIdField));
        panel.add(Box.createVerticalStrut(15));
        panel.add(makeField("Password", passwordField));
        panel.add(Box.createVerticalStrut(25));

        // 按鈕區
        JPanel btnPanel = new JPanel();
        loginButton = new JButton("登入");
        registerButton = new JButton("註冊");
        loginButton.setPreferredSize(new Dimension(120, 40));
        registerButton.setPreferredSize(new Dimension(120, 40));
        loginButton.setFont(new Font("SansSerif", Font.BOLD, 16));
        registerButton.setFont(new Font("SansSerif", Font.BOLD, 16));
        btnPanel.add(loginButton);
        btnPanel.add(Box.createHorizontalStrut(10));
        btnPanel.add(registerButton);
        panel.add(btnPanel);

        // 邏輯
        loginButton.addActionListener(e -> {
            String username = studentIdField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();
            if (DBHelper.login(username, password)) {
                onLoginSuccess.accept(username);
            } else {
                JOptionPane.showMessageDialog(panel, "Login failed. Please try again.");
            }
        });

        registerButton.addActionListener(e -> new RegisterFrame());
    }

    private JPanel makeField(String labelText, JComponent inputField) {
        JPanel container = new JPanel();
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("SansSerif", Font.PLAIN, 14));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        inputField.setAlignmentX(Component.LEFT_ALIGNMENT);
        container.setAlignmentX(Component.CENTER_ALIGNMENT);
        container.add(label);
        container.add(Box.createVerticalStrut(4));
        container.add(inputField);
        return container;
    }

    public JPanel getPanel() {
        return panel;
    }
}
