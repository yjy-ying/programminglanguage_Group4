import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.sql.*;

public class ChatClient {
    private JFrame frame;
    private JTextArea chatArea;
    private JTextField inputField;
    private JButton sendButton;
    private BufferedReader in;
    private PrintWriter out;
    private String viewerId;
    private int eventId;

    private static final String DB_URL = "jdbc:mysql://140.119.19.73:3315/MG10?useSSL=false&serverTimezone=UTC";
    private static final String USER = "MG10";
    private static final String PASSWORD = "JVkMkM";

    public ChatClient(String serverAddress, int port, int eventId, String username, String viewerID) {
        this.eventId = eventId;
        this.viewerId = viewerID;

        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ignored) {}

        frame = new JFrame("聊天室");
        chatArea = new JTextArea(20, 50);
        inputField = new JTextField();
        sendButton = new JButton("送出");

        chatArea.setFont(new Font("SansSerif", Font.PLAIN, 16));
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);

        inputField.setFont(new Font("SansSerif", Font.PLAIN, 16));
        sendButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        sendButton.setBackground(new Color(30, 144, 255));
        sendButton.setForeground(Color.WHITE);
        sendButton.setFocusPainted(false);

        JScrollPane scrollPane = new JScrollPane(chatArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        JPanel inputPanel = new JPanel(new BorderLayout(5, 5));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);

        frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
        frame.getContentPane().add(inputPanel, BorderLayout.SOUTH);
        frame.getContentPane().add(buildAvatarPanel(eventId), BorderLayout.NORTH);

        frame.pack();
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        ActionListener sendAction = e -> {
            String message = inputField.getText().trim();
            if (!message.isEmpty()) {
                out.println(viewerId + "::" + message);
                inputField.setText("");
            }
        };
        inputField.addActionListener(sendAction);
        sendButton.addActionListener(sendAction);

        connect(serverAddress, port);
        loadChatHistory();
    }

    private void connect(String serverIP, int port) {
        try {
            Socket socket = new Socket(serverIP, port);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            out.println(eventId);
            out.println(viewerId);

            new Thread(() -> {
                try {
                    String line;
                    while ((line = in.readLine()) != null) {
                        String[] parts = line.split("::", 2);
                        if (parts.length == 2) {
                            String senderId = parts[0];
                            String msg = parts[1];
                            String displayName = getDisplayName(viewerId, senderId);
                            chatArea.append(displayName + ": " + msg + "\n");
                            chatArea.setCaretPosition(chatArea.getDocument().getLength());
                        }
                    }
                } catch (IOException e) {
                    chatArea.append("\n[系統] 連線中斷\n");
                }
            }).start();

            frame.setVisible(true);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "無法連接伺服器", "錯誤", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void loadChatHistory() {
        String sql = "SELECT sender_id, message FROM chat_history WHERE event_id = ? ORDER BY id ASC";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, eventId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String senderId = rs.getString("sender_id");
                String msg = rs.getString("message");
                String displayName = getDisplayName(viewerId, senderId);
                chatArea.append(displayName + ": " + msg + "\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private JPanel buildAvatarPanel(int eventId) {
        JPanel avatarPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        avatarPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        avatarPanel.setBackground(Color.WHITE);

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {
        	String sql = "SELECT u.student_id, pf.profile_image_path " +
                    "FROM users u " +
                    "JOIN event_participants pa ON u.student_id = pa.userId " +
                    "LEFT JOIN profile pf ON u.student_id = pf.student_id " +
                    "WHERE pa.eventId = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, eventId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String sid = rs.getString("student_id");
                String imagePath = rs.getString("profile_image_path");
                String displayName = getDisplayName(viewerId, sid);

                ImageIcon icon;
                if (imagePath != null && !imagePath.isEmpty()) {
                    File imgFile = new File(imagePath);
                    icon = imgFile.exists() ? new ImageIcon(imgFile.getAbsolutePath()) : new ImageIcon("avatars/images.png");
                } else {
                    icon = new ImageIcon("avatars/default.png");
                }

                Image scaled = icon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
                JLabel avatarLabel = new JLabel(new ImageIcon(scaled));
                avatarLabel.setToolTipText(displayName);
                avatarLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

                avatarLabel.addMouseListener(new MouseAdapter() {
                    public void mouseClicked(MouseEvent e) {
                        try {
                            User user = UserDAO.getProfileByStudentId(sid);
                            new UserProfile(user, viewerId);
                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(frame, "無法載入個人檔案：" + ex.getMessage());
                        }
                    }
                });

                avatarPanel.add(avatarLabel);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return avatarPanel;
    }

    private String getDisplayName(String viewerId, String targetId) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASSWORD)) {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT nickname FROM Nicknames WHERE owner_id = ? AND target_id = ?"
            );
            ps.setString(1, viewerId);
            ps.setString(2, targetId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getString("nickname");

            ps = conn.prepareStatement("SELECT name FROM users WHERE student_id = ?");
            ps.setString(1, targetId);
            rs = ps.executeQuery();
            if (rs.next()) return rs.getString("name");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return targetId;
    }

}

