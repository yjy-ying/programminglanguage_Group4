import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class EmailSender {
    private static final String FROM = "eatingwhenever@gmail.com";
    private static final String PASSWORD = "gtoo arad ahzk vjgi";
    private static final ZoneId TAIWAN_ZONE = ZoneId.of("Asia/Taipei");
    
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public static void send(String to, String subject, String messageBody) {
        sendEmailOnly(to, subject, messageBody);
        sendToInternalMailbox(to, subject, messageBody);
    }

    private static void sendEmailOnly(String to, String subject, String messageBody) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(FROM, PASSWORD);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(FROM));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject(subject);
            message.setText(messageBody);
            Transport.send(message);
            
            System.out.println("✅ 郵件已發送至: " + to + " (台灣時間: " + formatTaiwanTime(nowInTaiwan()) + ")");
        } catch (MessagingException e) {
            System.err.println("❌ 郵件發送失敗: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void sendToInternalMailbox(String email, String subject, String messageBody) {
        String userId = email.split("@")[0];
        String currentTime = formatTaiwanTime(nowInTaiwan());
        String customSubject = "[" + currentTime + " 台灣時間] 📌 " + subject;
        
        try {
            MessageHelper.sendMessage(userId, customSubject + "\n\n" + messageBody);
            System.out.println("✅ 系統訊息已發送至用戶: " + userId + " (台灣時間: " + currentTime + ")");
        } catch (Exception e) {
            System.err.println("❌ 無法將提醒送入系統信箱：" + e.getMessage());
        }
    }

    public static String formatTaiwanTime(LocalDateTime time) {
        return time.atZone(TAIWAN_ZONE).format(FORMATTER);
    }

    public static LocalDateTime nowInTaiwan() {
        return LocalDateTime.now(TAIWAN_ZONE);
    }

    public static ZonedDateTime toTaiwanZoned(LocalDateTime time) {
        return time.atZone(TAIWAN_ZONE);
    }
    
    public static String formatTaiwanTimeWithTimezone(LocalDateTime time) {
        ZonedDateTime taiwanTime = time.atZone(TAIWAN_ZONE);
        DateTimeFormatter formatterWithTZ = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss (GMT+8)");
        return taiwanTime.format(formatterWithTZ);
    }
}