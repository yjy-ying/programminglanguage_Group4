
import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.*;

public class ChatServer {
    private static final int PORT = 12345;
    private static final Map<Integer, List<ClientHandler>> roomMap = new HashMap<>();

    private static final String DB_URL = "jdbc:mysql://140.119.19.73:3315/MG10?useSSL=false&serverTimezone=UTC";
    private static final String USER = "MG10";
    private static final String PASSWORD = "JVkMkM";

    public static void main(String[] args) {
        System.out.println("[伺服器] 啟動成功，等待連線中...");
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                Socket socket = serverSocket.accept();
                new ClientHandler(socket).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static synchronized void broadcastToRoom(int eventId, String senderId, String message) {
        List<ClientHandler> clients = roomMap.get(eventId);
        if (clients != null) {
            String formattedMessage = senderId + "::" + message;
            System.out.println("發送訊息：" + formattedMessage);
            for (ClientHandler client : clients) {
                client.sendMessage(formattedMessage);
            }
        }
    }

    public static synchronized void removeClient(int eventId, ClientHandler handler) {
        List<ClientHandler> clients = roomMap.get(eventId);
        if (clients != null) {
            clients.remove(handler);
        }
    }

    public static void saveMessage(int eventId, String senderId, String message) {
        String sql = "INSERT INTO chat_history (event_id, sender_id, message) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, eventId);
            stmt.setString(2, senderId);
            stmt.setString(3, message);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("[資料庫] 儲存訊息失敗: " + e.getMessage());
        }
    }

    private static class ClientHandler extends Thread {
        private final Socket socket;
        private PrintWriter out;
        private BufferedReader in;
        private int eventId;
        private String senderId;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public void sendMessage(String msg) {
            if (out != null)
                out.println(msg);
        }

        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                eventId = Integer.parseInt(in.readLine());
                senderId = in.readLine();

                synchronized (ChatServer.class) {
                    roomMap.putIfAbsent(eventId, new ArrayList<>());
                    roomMap.get(eventId).add(this);
                }

                String line;
                while ((line = in.readLine()) != null) {
                    broadcastToRoom(eventId, senderId, line);
                    saveMessage(eventId, senderId, line);
                }
            } catch (IOException | NumberFormatException e) {
                System.out.println("[系統] 使用者離線: " + senderId);
            } finally {
                removeClient(eventId, this);
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

