
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class DatabaseHelper {
    private static final String DB_URL = "jdbc:mysql://140.119.19.73:3315/MG10?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "MG10";
    private static final String DB_PASS = "JVkMkM";

    public static int createEvent(String location, String creatorId, LocalDateTime eventTime, int limit) {
        String sql = "INSERT INTO dining_events (location, creator_id, event_time, participant_limit) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, location);
            stmt.setString(2, creatorId);
            stmt.setTimestamp(3, Timestamp.valueOf(eventTime));
            stmt.setInt(4, limit);

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.err.println("❗ 建立活動失敗：" + e.getMessage());
        }
        return -1;
    }

    public static void joinEvent(int eventId, String userId) {
        String sql = "INSERT INTO event_participants (eventId, userId) VALUES (?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, eventId);
            stmt.setString(2, userId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("❗ 加入活動失敗：" + e.getMessage());
        }
    }

    public static void cancelEvent(int eventId, String userId) throws SQLException {
        String sql = "DELETE FROM event_participants WHERE eventId = ? AND userId = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, eventId);
            stmt.setString(2, userId);
            stmt.executeUpdate();
        }
    }

    public static void deleteEvent(int eventId) throws SQLException {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            conn.setAutoCommit(false);
            try {
                String deleteParticipants = "DELETE FROM event_participants WHERE eventId = ?";
                try (PreparedStatement stmt = conn.prepareStatement(deleteParticipants)) {
                    stmt.setInt(1, eventId);
                    stmt.executeUpdate();
                }

                String deleteEvent = "DELETE FROM dining_events WHERE id = ?";
                try (PreparedStatement stmt = conn.prepareStatement(deleteEvent)) {
                    stmt.setInt(1, eventId);
                    stmt.executeUpdate();
                }

                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    public static Set<String> getEventParticipants(String eventId) {
        Set<String> participants = new HashSet<>();
        String sql = "SELECT userId FROM event_participants WHERE eventId = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, Integer.parseInt(eventId));
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                participants.add(rs.getString("userId")); 
            }
        } catch (SQLException e) {
            System.err.println("❗ 查詢參與者失敗：" + e.getMessage());
        }
        return participants;
    }



    public static ArrayList<DiningEvent> loadEvents() {
        ArrayList<DiningEvent> events = new ArrayList<>();
        String sql = "SELECT * FROM dining_events";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String location = rs.getString("location");
                String creatorId = rs.getString("creator_id");
                LocalDateTime eventTime = rs.getTimestamp("event_time").toLocalDateTime();
                int limit = rs.getInt("participant_limit");
                Set<String> participants = getEventParticipants(String.valueOf(id));

                events.add(new DiningEvent(id, location, creatorId, participants, eventTime, limit));
            }
        } catch (SQLException e) {
            System.err.println("❗ 載入活動清單失敗：" + e.getMessage());
        }
        return events;
    }

    public static void setNickname(String ownerId, String targetId, String nickname) throws SQLException {
        String sql = "REPLACE INTO Nicknames (owner_id, target_id, nickname) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, ownerId);
            stmt.setString(2, targetId);
            stmt.setString(3, nickname);
            stmt.executeUpdate();
        }
    }

    public static void deleteNickname(String ownerId, String targetId) throws SQLException {
        String sql = "DELETE FROM Nicknames WHERE owner_id = ? AND target_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, ownerId);
            stmt.setString(2, targetId);
            stmt.executeUpdate();
        }
    }
    
    public static String getNickname(String viewerId, String targetId) {
        String sql = "SELECT nickname FROM Nicknames WHERE owner_id = ? AND target_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, viewerId);
            stmt.setString(2, targetId);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("nickname");
            }

        } catch (SQLException e) {
            System.err.println("❗ 查詢暱稱失敗：" + e.getMessage());
        }

        return null;
    }

}


