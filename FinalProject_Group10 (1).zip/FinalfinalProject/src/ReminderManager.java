import java.sql.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ReminderManager {
    private static final String DB_URL = "jdbc:mysql://140.119.19.73:3315/MG10?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "MG10";
    private static final String DB_PASS = "JVkMkM";

    private static final ZoneId TAIPEI = ZoneId.of("Asia/Taipei");
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private static Timer reminderTimer;

    private static LocalDateTime nowInTaiwan() {
        return LocalDateTime.now(TAIPEI);
    }

    private static String formatTaiwanTime(LocalDateTime time) {
        return time.atZone(TAIPEI).format(FORMATTER);
    }

    public static void startReminderService() {
        if (reminderTimer != null) {
            reminderTimer.cancel();
        }

        reminderTimer = new Timer("ReminderService", true);
        reminderTimer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                try {
                    runAllReminders();
                } catch (Exception e) {
                    System.err.println("❗ 活動提醒執行失敗: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }, 0, 5 * 60 * 1000);
    }

    public static void stopReminderService() {
        if (reminderTimer != null) {
            reminderTimer.cancel();
            reminderTimer = null;
            System.out.println("❌ 活動提醒已停止");
        }
    }

    public static void runAllReminders() {
        List<String> allUserIds = getAllUserIds();
        for (String userId : allUserIds) {
            sendUpcomingEventReminders(userId);
        }
    }

    public static void sendUpcomingEventReminders(String userId) {
        try {
            ArrayList<DiningEvent> events = DatabaseHelper.loadEvents();
            LocalDateTime now = nowInTaiwan();

            for (DiningEvent event : events) {
                if (event.isJoined(userId)) {
                    LocalDateTime remindTime = event.getEventTime().minusHours(1);

                    if (remindTime.isBefore(now) && event.getEventTime().isAfter(now)) {
                        String msg = "您報名的活動「" + event.getLocation() + "」即將開始（開始時間：" +
                                formatTaiwanTime(event.getEventTime()) + "）請記得去見您的飯飯之交";

                        if (!hasSentReminder(userId, msg)) {
                            MessageHelper.sendMessage(userId, msg);
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("❗ 發送使用者提醒失敗: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static boolean hasSentReminder(String userId, String content) {
        String sql = "SELECT COUNT(*) FROM mailbox WHERE user_id = ? AND content = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, userId);
            stmt.setString(2, content);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("❗ 查詢是否已寄送提醒失敗: " + e.getMessage());
        }
        return false;
    }

    private static List<String> getAllUserIds() {
        List<String> userIds = new ArrayList<>();
        String sql = "SELECT student_id FROM users";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                userIds.add(rs.getString("student_id"));
            }

        } catch (SQLException e) {
            System.err.println("❗ 讀取使用者 ID 失敗: " + e.getMessage());
        }

        return userIds;
    }
}
