// RegisterFrame.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class RegisterFrame extends JFrame {
    private JTextField studentIdField, nameField, verificationField;
    private JPasswordField passwordField;
    private JButton sendCodeButton, registerButton;
    private String verificationCode;

    public RegisterFrame() {
        setTitle("註冊");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("SIGN UP", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 10, 30));

        nameField = new JTextField();
        studentIdField = new JTextField();
        passwordField = new JPasswordField();
        verificationField = new JTextField();

        inputPanel.add(new JLabel("Name:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Student ID:"));
        inputPanel.add(studentIdField);
        inputPanel.add(new JLabel("Password:"));
        inputPanel.add(passwordField);
        inputPanel.add(new JLabel("Verification Code:"));
        inputPanel.add(verificationField);

        mainPanel.add(inputPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        sendCodeButton = new JButton("發送驗證碼");
        registerButton = new JButton("註冊");

        sendCodeButton.addActionListener(this::sendCode);
        registerButton.addActionListener(this::verifyAndRegister);

        buttonPanel.add(sendCodeButton);
        buttonPanel.add(registerButton);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        add(mainPanel);
        setVisible(true);
    }

    private void sendCode(ActionEvent e) {
        String studentId = studentIdField.getText();
        verificationCode = String.format("%04d", (int)(Math.random() * 10000));
        String email = studentId + "@nccu.edu.tw";
        EmailSender.send(email, "驗證碼通知", "您的驗證碼是：" + verificationCode);
        JOptionPane.showMessageDialog(this, "Verification code sent to " + email);
    }

    private void verifyAndRegister(ActionEvent e) {
        if (verificationField.getText().equals(verificationCode)) {
            boolean success = DBHelper.register(
                nameField.getText(),
                studentIdField.getText(),
                new String(passwordField.getPassword()),
                verificationCode
            );

            if (success) {
                JOptionPane.showMessageDialog(this, "註冊成功，請登入！");
                dispose(); 
            } else {
                JOptionPane.showMessageDialog(this, "註冊失敗，帳號可能已存在。");
            }
        } else {
            JOptionPane.showMessageDialog(this, "驗證碼錯誤，請重新輸入。");
        }
    }

}
